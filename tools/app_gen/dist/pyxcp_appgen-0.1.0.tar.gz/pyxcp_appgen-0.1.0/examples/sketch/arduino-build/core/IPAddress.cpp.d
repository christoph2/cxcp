C:\csProjects\cxcp\tools\app_gen\sketch\arduino-build\core\IPAddress.cpp.o: \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino\IPAddress.cpp \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/Arduino.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/binary.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/WCharacter.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/WString.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/HardwareSerial.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/Stream.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/Print.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/Printable.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/USBAPI.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/Arduino.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\variants\standard/pins_arduino.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino/IPAddress.h
