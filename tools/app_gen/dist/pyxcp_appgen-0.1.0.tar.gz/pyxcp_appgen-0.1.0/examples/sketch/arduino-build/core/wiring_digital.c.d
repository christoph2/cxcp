C:\csProjects\cxcp\tools\app_gen\sketch\arduino-build\core\wiring_digital.c.o: \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino\wiring_digital.c \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino\wiring_private.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino\Arduino.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\cores\arduino\binary.h \
 C:\Users\Chris\AppData\Local\Arduino15\packages\arduino\hardware\avr\1.8.7\variants\standard/pins_arduino.h
