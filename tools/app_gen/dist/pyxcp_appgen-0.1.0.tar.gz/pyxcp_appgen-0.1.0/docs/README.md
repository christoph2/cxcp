# pyxcp-appgen

Arduino-based cXCP/pyXCP code generator and build/upload frontend.

## Overview

`pyxcp-appgen` generates Arduino sketch source code and A2L files from a JSON
project model, compiles and uploads the sketch via `arduino-cli`, and produces
a pyXCP recorder configuration.

## Installation

```bash
pip install -e .
```

## Usage

```bash
pyxcp-appgen <model.json> [generate|build|a2l|upload|clean] [--force]
```

| Command    | Description                                      |
|------------|--------------------------------------------------|
| `generate` | Generate Arduino sketch from JSON model          |
| `build`    | Compile sketch to ELF via arduino-cli            |
| `a2l`      | Extract ELF symbols and generate A2L + XCP config|
| `upload`   | Upload compiled sketch to the board              |
| `clean`    | Remove build artifacts                           |

Omitting a command runs the full chain: `generate` → `build` → `a2l`.

## Project structure

```
tools/app_gen/
├── src/pyxcp_appgen/   # Python package
│   └── templates/      # Mako templates
├── tests/              # pytest tests
├── docs/               # Documentation
├── examples/           # Example projects and scripts
└── pyproject.toml
```
